
from Audio.fastComputation.fastComputation import fastComputation

fastComputation.lcs()